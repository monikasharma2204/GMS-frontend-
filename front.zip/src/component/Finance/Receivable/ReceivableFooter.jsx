import React from "react";
import { Box, Button, Typography } from "@mui/material";
import { useRecoilState, useSetRecoilState } from "recoil";
import { receivableFormDataState, receivableValidationErrorState, receivableFSMState } from "../../../recoil/state/FinanceState";
import apiRequest from "../../../helpers/apiHelper";
import CustomConfirmDialog from "../../Commons/CustomConfirmDialog";
import SuccessModal from "../../Commons/SuccessModal";

const ReceivableFooter = () => {
  const [formData, setFormData] = useRecoilState(receivableFormDataState);
  const [fsmState, setFsmState] = useRecoilState(receivableFSMState);
  const setValidationError = useSetRecoilState(receivableValidationErrorState);
  const [confirmOpen, setConfirmOpen] = React.useState(false);
  const [cancelConfirmOpen, setCancelConfirmOpen] = React.useState(false);
  const [successOpen, setSuccessOpen] = React.useState(false);

  const isDirty = React.useMemo(() => {

    return (
      formData.account !== null ||
      formData.items.length > 0 ||
      formData.ref1 !== "" ||
      formData.ref2 !== "" ||
      formData.note !== "" ||
      formData.paymentMethods.cash.amount !== 0 ||
      formData.paymentMethods.bankTransfer.amount !== 0 ||
      formData.paymentMethods.creditCard.amount !== 0 ||
      formData.paymentMethods.other.amount !== 0
    );
  }, [formData]);

  const handleSaveClick = () => {
    if (!formData.account) {
      setValidationError("Please fill out the required field.");
      return;
    }
    if (formData.items.length === 0) {
      setValidationError("Please fill out the required field.");
      return;
    }

    const grandTotal = formData.items.reduce((sum, item) => sum + (parseFloat(item.receive) || 0), 0);
    const paymentTotal =
      parseFloat(formData.paymentMethods.cash.amount || 0) +
      parseFloat(formData.paymentMethods.bankTransfer.amount || 0) +
      parseFloat(formData.paymentMethods.creditCard.amount || 0) +
      parseFloat(formData.paymentMethods.other.amount || 0);

    if (Math.abs(grandTotal - paymentTotal) > 0.01 && grandTotal > 0) {
      setValidationError("Please fill out the required field.");
      return;
    }

    setValidationError(null);
    setConfirmOpen(true);
  };

  const handleSave = async (confirmed) => {
    setConfirmOpen(false);
    if (!confirmed) return;

    try {
      const slipImage = formData.paymentMethods.bankTransfer.slip_image;
      let payload;

      if (slipImage instanceof File) {
        payload = new FormData();
        payload.append("doc_date", formData.docDate || new Date().toISOString());
        payload.append("account", formData.account?.vendor_code_name || formData.account?.label || formData.account);
        payload.append("currency", formData.currencyId);
        payload.append("ref_1", formData.ref1 || "");
        payload.append("ref_2", formData.ref2 || "");
        payload.append("note", formData.note || "");

        payload.append("items", JSON.stringify(formData.items.map(item => ({
          _id: item._id,
          sale_no: item.saleNo,
          out_standing: item.outstanding,
          receive: item.receive,
          balance: item.balance,
          remark: item.remark
        }))));

        const grandTotalVal = formData.items.reduce((sum, item) => sum + (parseFloat(item.receive) || 0), 0).toFixed(2);

        payload.append("payment_method", JSON.stringify({
          cash: formData.paymentMethods.cash.amount || "0",
          credit: formData.paymentMethods.creditCard.amount || "0",
          credit_comment: formData.paymentMethods.creditCard.note || "",
          internet_banking: formData.paymentMethods.bankTransfer.amount || "0",
          other: formData.paymentMethods.other.amount || "0",
          other_comment: formData.paymentMethods.other.note || "",
          grand_total: grandTotalVal
        }));

        payload.append("slip_image", slipImage);
      } else {
        payload = {
          doc_date: formData.docDate || new Date(),
          account: formData.account?.vendor_code_name || formData.account?.label || formData.account,
          currency: formData.currencyId,
          items: formData.items.map(item => ({
            _id: item._id,
            sale_no: item.saleNo,
            out_standing: item.outstanding,
            receive: item.receive,
            balance: item.balance,
            remark: item.remark
          })),
          payment_method: {
            cash: formData.paymentMethods.cash.amount || "0",
            credit: formData.paymentMethods.creditCard.amount || "0",
            credit_comment: formData.paymentMethods.creditCard.note || "",
            internet_banking: formData.paymentMethods.bankTransfer.amount || "0",
            other: formData.paymentMethods.other.amount || "0",
            other_comment: formData.paymentMethods.other.note || "",
            slip_image: slipImage,
            grand_total: formData.items.reduce((sum, item) => sum + (parseFloat(item.receive) || 0), 0).toFixed(2)
          },
          ref_1: formData.ref1 || "",
          ref_2: formData.ref2 || "",
          note: formData.note || ""
        };
      }

      const response = await apiRequest("POST", "/receivables", payload);
      if (response) {
        setSuccessOpen(true);
        setFsmState("view");
        setFormData(prev => ({ ...prev, id: response._id || response.id || response.data?._id || response.data?.id }));
      }
    } catch (error) {
      console.error("Failed to save receivable:", error);
      alert("Error saving receivable: " + (error.response?.data?.message || error.message));
    }
  };

  const handleCancelReceivable = async () => {
    setCancelConfirmOpen(false);
    try {
      const response = await apiRequest("PUT", `/receivables/${formData.id}/cancel`);
      if (response) {
        setSuccessOpen(true);
        // Refresh or update status
        setTimeout(() => window.location.reload(), 1500);
      }
    } catch (error) {
      console.error("Failed to cancel receivable:", error);
      alert("Error cancelling receivable: " + (error.response?.data?.message || error.message));
    }
  };

  return (
    <>
      <Box
        sx={{
          width: "calc(100% - 222px)",
          left: "222px",
          right: 0,
          height: "65px",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          borderTop: "1px solid #BFBFBF",
          gap: "12px",
          position: "fixed",
          bottom: "0",
          backgroundColor: "#FFF",
          zIndex: 5,
          padding: "0 32px",
          boxSizing: "border-box"
        }}
      >
        <Box sx={{ display: "flex", gap: "12px" }}>
          <Button
            onClick={() => window.location.reload()}
            disabled={fsmState !== "view"}
            sx={{
              textTransform: "none",
              height: "45px",
              width: "84px",
              borderRadius: "4px",
              backgroundColor: "#05595B",
              color: "#FFF",
              fontFamily: "Calibri",
              fontSize: "16px",
              fontWeight: 700,
              "&:hover": { backgroundColor: "#044a4c" },
              "&.Mui-disabled": { backgroundColor: "#E6E6E6", color: "#57646E" }
            }}
          >
            Add
          </Button>

        </Box>

        <Box sx={{ display: "flex", gap: "12px", alignItems: "center" }}>
          <Button
            variant="outlined"
            disabled={!isDirty || fsmState === "view"}
            onClick={() => {
              window.location.reload();
            }}
            sx={{
              textTransform: "none",
              height: "45px",
              width: "100px",
              borderRadius: "4px",
              borderColor: "#BFBFBF",
              color: "#343434",
              fontFamily: "Calibri",
              fontSize: "16px",
              fontWeight: 700,
              "&:hover": { borderColor: "#999", bgcolor: "rgba(0, 0, 0, 0.04)" },
              "&.Mui-disabled": { borderColor: "#E0E0E0", color: "#BDBDBD" }
            }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSaveClick}
            disabled={!isDirty || fsmState === "view"}
            sx={{
              textTransform: "none",
              height: "45px",
              width: "84px",
              borderRadius: "4px",
              backgroundColor: "#05595B",
              color: "#FFF",
              fontFamily: "Calibri",
              fontSize: "16px",
              fontWeight: 700,
              "&:hover": { backgroundColor: "#044a4c" },
              "&.Mui-disabled": { backgroundColor: "#E6E6E6", color: "#57646E" }
            }}
          >
            Save
          </Button>

          <Box
            sx={{
              "&:hover svg path": {
                fill: "#E9B238",
              },
              cursor: "pointer",
              marginLeft: "8px",
            }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="28"
              height="28"
              viewBox="0 0 28 28"
              fill="none"
            >
              <path
                d="M8.16671 2.33398C7.85729 2.33398 7.56054 2.4569 7.34175 2.67569C7.12296 2.89449 7.00004 3.19123 7.00004 3.50065V8.16732H4.66671C4.04787 8.16732 3.45438 8.41315 3.01679 8.85074C2.57921 9.28832 2.33337 9.88181 2.33337 10.5007V19.834C2.33337 20.4528 2.57921 21.0463 3.01679 21.4839C3.45438 21.9215 4.04787 22.1673 4.66671 22.1673H7.00004V24.5007C7.00004 24.8101 7.12296 25.1068 7.34175 25.3256C7.56054 25.5444 7.85729 25.6673 8.16671 25.6673H19.8334C20.1428 25.6673 20.4395 25.5444 20.6583 25.3256C20.8771 25.1068 21 24.8101 21 24.5007V22.1673H23.3334C23.9522 22.1673 24.5457 21.9215 24.9833 21.4839C25.4209 21.0463 25.6667 20.4528 25.6667 19.834V10.5007C25.6667 9.88181 25.4209 9.28832 24.9833 8.85074C24.5457 8.41315 23.9522 8.16732 23.3334 8.16732H21V3.50065C21 3.19123 20.8771 2.89449 20.6583 2.67569C20.4395 2.4569 20.1428 2.33398 19.8334 2.33398H8.16671ZM19.8334 16.334H8.16671C7.85729 16.334 7.56054 16.4569 7.34175 16.6757C7.12296 16.8945 7.00004 17.1912 7.00004 17.5007V19.834H4.66671V10.5007H23.3334V19.834H21V17.5007C21 17.1912 20.8771 16.8945 20.6583 16.6757C20.4395 16.4569 20.1428 16.334 19.8334 16.334ZM18.6667 8.16732H9.33337V4.66732H18.6667V8.16732ZM5.83337 11.6673V14.0007H9.33337V11.6673H5.83337ZM18.6667 18.6673V23.334H9.33337V18.6673H18.6667Z"
                fill="#05595B"
              />
            </svg>
          </Box>

          <Box

            sx={{
              cursor: "pointer",
              "&:hover svg path": {
                fill: "#00AA3A",
              },
              marginRight: "8px",
            }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="25"
              height="25"
              viewBox="0 0 25 25"
              fill="none"
            >
              <path
                d="M19.4175 1.7L17.8862 0H5.8275C4.9575 0 4.62125 0.645 4.62125 1.14875V5.68625H6.3125V2.06625C6.3125 1.87375 6.475 1.71125 6.6625 1.71125H15.2913C15.4812 1.71125 15.5763 1.745 15.5763 1.90125V7.92625H21.7175C21.9587 7.92625 22.0525 8.05125 22.0525 8.23375V22.9463C22.0525 23.2537 21.9275 23.3 21.74 23.3H6.6625C6.56952 23.2977 6.48106 23.2595 6.41576 23.1932C6.35047 23.127 6.31345 23.038 6.3125 22.945V21.6H4.6325V23.7188C4.61 24.4688 5.01 25 5.8275 25H22.575C23.45 25 23.7488 24.3663 23.7488 23.7887V6.48375L23.3113 6.00875L19.4175 1.7ZM17.295 1.9L17.7787 2.4425L21.0238 6.00875L21.2025 6.225H17.8862C17.6362 6.225 17.4775 6.18375 17.4112 6.1C17.345 6.01875 17.3062 5.8875 17.295 5.70875V1.9ZM15.9325 13.3337H21.6537V15.0013H15.9312L15.9325 13.3337ZM15.9325 10.0013H21.6537V11.6675H15.9312L15.9325 10.0013ZM15.9325 16.6675H21.6537V18.335H15.9312L15.9325 16.6675ZM1.25 7.0325V20.3662H14.3313V7.0325H1.25ZM7.79125 14.7875L6.99125 16.01H7.79125V17.5H3.77L6.6875 13.1125L4.1025 9.1675H6.2625L7.7925 11.4625L9.32125 9.1675H11.48L8.89 13.1125L11.8113 17.5H9.57L7.79125 14.7875Z"
                fill="#05595B"
              />
            </svg>
          </Box>
        </Box>
      </Box>
      <CustomConfirmDialog
        open={confirmOpen}
        onConfirm={handleSave}
        title="Would you like to save?"
      />
      <CustomConfirmDialog
        open={cancelConfirmOpen}
        onConfirm={handleCancelReceivable}
        onClose={() => setCancelConfirmOpen(false)}
        title="Confirm Receivable Cancellation"
        subtitle={
          <Box sx={{ color: "#343434", mt: 1 }}>
            <Typography sx={{ fontWeight: 700, fontSize: "16px", mb: 1 }}>Warning</Typography>
            <Typography sx={{ fontSize: "14px", display: "flex", alignItems: "center", gap: 1 }}>
              <span style={{ fontSize: "20px" }}>•</span> Document status will be changed to Cancelled.
            </Typography>
            <Typography sx={{ fontSize: "14px", display: "flex", alignItems: "center", gap: 1 }}>
              <span style={{ fontSize: "20px" }}>•</span> This action cannot be undone.
            </Typography>
          </Box>
        }
      />
      <SuccessModal
        open={successOpen}
        onClose={() => setSuccessOpen(false)}
        message="Saved successfully"
      />
    </>
  );
};

export default ReceivableFooter;
