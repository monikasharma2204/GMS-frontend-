import React, { useEffect, useReducer, useState } from "react";
import { Box, Button, Typography, Grid } from "@mui/material";
import ModalDayBook from "./ModalDayBook";
import apiRequest from "../../helpers/apiHelper.js";
import { useRecoilState } from "recoil";
import { editMemoState } from "recoil/MemoState.js";

import { DayBookQuotationState } from "recoil/state/QuotationState";

const QuotationsOrderHeader = ({
  state,
  handleSaveMemo,
  setDueDate,
  handleEdit,
  open,
  setOpen,  
}) => {
  const [inventoryData, setInventoryData] = useState([]);
  const [editMemoStatus, setEditMemoStatus] = useRecoilState(editMemoState);
  const [isDisableDayBook, setIsDisableDayBook] = useState(false);
  const [dayBookQuotation, setDayBookQuotation] = useRecoilState(
    DayBookQuotationState
  );

  const getInventoryData = async () => {
    try {
      const response = await apiRequest("GET", "/quotations");
      console.log(response, "response day ");
      const inventoryData = response.map((el) => {
        return {
          ...el,
          inventory_item: el.items.map((inventory) => {
            return {
              ...inventory,
              // weight: Number(inventory.weight["$numberDecimal"]) || 0,
              // total_amount: Number(inventory.total_amount["$numberDecimal"]) || 0,
              // price: Number(inventory.price["$numberDecimal"]) || 0,
              // discount_percent: Number(inventory.discount_percent["$numberDecimal"]) || 0,
              // discount_amount: Number(inventory.discount_amount["$numberDecimal"]) || 0,
              // amount: Number(inventory.amount["$numberDecimal"]) || 0
            };
          }),
        };
      });

      setInventoryData(inventoryData);
    } catch (e) {
      console.log(e);
    }
  };

  // useEffect(() => {
  //     if(inventoryData.length > 0) {
  //       setIsDisableDayBook(true)
  //     }
  // }, [inventoryData])

  useEffect(() => {
    if(open){
      getInventoryData();
    }
   
  }, [open]);

  const handleCheckboxChange = (inventory) => {
    const newInventoryData = inventoryData.map((item) => {
      if (item._id == inventory._id) {
        return {
          ...item,
          checked: !inventory.checked,
        };
      } else {
        return item;
      }
    });
    setInventoryData(newInventoryData);
  };

  const handleDayBookSubmit = () => {
    const inventoryDataSelected = [];
    console.log(inventoryData, "jjkkjj");
    inventoryData.map((item) => {
      return item.inventory_item
        .filter((el) => el.checked)
        .map((inventory) => {
          const inventoryData = {
            ...item,
            ...inventory,
            lot_no: inventory.lot_no,
            stone: inventory.stone,
            size: inventory.size,
            color: inventory.color,
            cutting: inventory.cutting,
            quality: inventory.quality,
            clarity: inventory.clarity,
            cer_type: inventory.cer_type,
            cer_no: inventory.cer_no,
            disabled: true,
          };
          delete inventoryData.inventory_item;
          // inventoryDataSelected.push(inventoryData)
          inventoryDataSelected[0] = inventoryData;
        });
    });

    let selectedItems = state.selectedItems;
    selectedItems.filter(
      (el) =>
        !el._id || inventoryDataSelected.map((el) => el._id).includes(el._id)
    );

    const remainSelected = inventoryDataSelected.filter(
      (el) => !selectedItems.map((el) => el._id).includes(el._id)
    );
    selectedItems = selectedItems.concat(remainSelected);

    // setDueDate(doc_date)
    setDayBookQuotation(selectedItems[0]);

    // {
    //   "code": "",
    //   "label": "",
    //   "invoiceAddress": [
    //     {
    //       "code": "",
    //       "label": ""
    //     }
    //   ],
    //   "shippingAddress": [
    //     {
    //       "code": "",
    //       "label": ""
    //     }
    //   ]
    // }
    console.log("account", selectedItems[0].account);
    console.log("selectedItems", selectedItems);

    setIsDisableDayBook(true);
    handleSaveMemo(selectedItems);
  };
  const calculateSums = (dataArray) =>
    dataArray.reduce(
      (totals, item) => {
        totals.weight += item.weight || 0;
        totals.pcs += item.pcs || 0;
        totals.amount += item.amount || 0;
        return totals;
      },
      { amount: 0, pcs: 0, weight: 0 }
    );

  return (
    <>
      <Box
        sx={{
          width: "1697px",
          height: "64px",
          flexShrink: 0,
          backgroundColor: "#FFF",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          boxShadow: "0px 8px 8px -4px rgba(24, 39, 75, 0.08)",
        }}
      >
        <Box
          sx={{
            width: "388px",
            alignItems: "center",
          }}
        >
          <Typography
            sx={{
              color: "#05595B",
              fontFamily: "Calibri",
              fontSize: "24px",
              fontStyle: "normal",
              fontWeight: 700,
              lineHeight: "normal",
              marginLeft: "32px",
            }}
          >
            Quotation
          </Typography>
        </Box>

        <Box sx={{ display: "flex", alignItems: "center" }}>
          <Box>
            <ModalDayBook
              data={inventoryData}
              handleEdit={handleEdit}
              state={state}
              handleCheckboxChange={handleCheckboxChange}
              handleSubmit={handleDayBookSubmit}
              setDueDate={setDueDate}
              isDisableDayBook={isDisableDayBook}
              calculateSums={calculateSums}
              open={open}
              setOpen={setOpen}
            />
          </Box>

          {/* <Box>
            <Button
                onClick={
                  ()=>{
                    setEditMemoStatus(false)
                  }
                }
              sx={{
                textTransform: "none",
                height: "35px",
                width: "84px",
                padding: "12px",
                borderRadius: "4px",
                gap: "8px",
                marginRight: "24px",
                backgroundColor: "#C6A969",
                "&:hover": {
                  backgroundColor: "#C6A969",
                },
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
              >
                <path
                  d="M7 17.0134L11.413 16.9984L21.045 7.45839C21.423 7.08039 21.631 6.57839 21.631 6.04439C21.631 5.51039 21.423 5.00839 21.045 4.63039L19.459 3.04439C18.703 2.28839 17.384 2.29239 16.634 3.04139L7 12.5834V17.0134ZM18.045 4.45839L19.634 6.04139L18.037 7.62339L16.451 6.03839L18.045 4.45839ZM9 13.4174L15.03 7.44439L16.616 9.03039L10.587 15.0014L9 15.0064V13.4174Z"
                  fill="white"
                />
                <path
                  d="M5 21H19C20.103 21 21 20.103 21 19V10.332L19 12.332V19H8.158C8.132 19 8.105 19.01 8.079 19.01C8.046 19.01 8.013 19.001 7.979 19H5V5H11.847L13.847 3H5C3.897 3 3 3.897 3 5V19C3 20.103 3.897 21 5 21Z"
                  fill="white"
                />
              </svg>
              <Typography
                sx={{
                  color: "var(--jw-background-white-textwhite, #FFF)",
                  fontFamily: "Calibri",
                  fontSize: "16px",
                  fontStyle: "normal",
                  fontWeight: 700,
                  lineHeight: "normal",
                  letterSpacing: "1px",
                }}
              >
                Edit
              </Typography>
            </Button>
          </Box> */}

          <Box
            sx={{
              marginRight: "12px",
              "&:hover svg path": {
                fill: "#E9B238",
              },
            }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="28"
              height="28"
              viewBox="0 0 28 28"
              fill="none"
            >
              <path
                d="M8.16671 2.33398C7.85729 2.33398 7.56054 2.4569 7.34175 2.67569C7.12296 2.89449 7.00004 3.19123 7.00004 3.50065V8.16732H4.66671C4.04787 8.16732 3.45438 8.41315 3.01679 8.85074C2.57921 9.28832 2.33337 9.88181 2.33337 10.5007V19.834C2.33337 20.4528 2.57921 21.0463 3.01679 21.4839C3.45438 21.9215 4.04787 22.1673 4.66671 22.1673H7.00004V24.5007C7.00004 24.8101 7.12296 25.1068 7.34175 25.3256C7.56054 25.5444 7.85729 25.6673 8.16671 25.6673H19.8334C20.1428 25.6673 20.4395 25.5444 20.6583 25.3256C20.8771 25.1068 21 24.8101 21 24.5007V22.1673H23.3334C23.9522 22.1673 24.5457 21.9215 24.9833 21.4839C25.4209 21.0463 25.6667 20.4528 25.6667 19.834V10.5007C25.6667 9.88181 25.4209 9.28832 24.9833 8.85074C24.5457 8.41315 23.9522 8.16732 23.3334 8.16732H21V3.50065C21 3.19123 20.8771 2.89449 20.6583 2.67569C20.4395 2.4569 20.1428 2.33398 19.8334 2.33398H8.16671ZM19.8334 16.334H8.16671C7.85729 16.334 7.56054 16.4569 7.34175 16.6757C7.12296 16.8945 7.00004 17.1912 7.00004 17.5007V19.834H4.66671V10.5007H23.3334V19.834H21V17.5007C21 17.1912 20.8771 16.8945 20.6583 16.6757C20.4395 16.4569 20.1428 16.334 19.8334 16.334ZM18.6667 8.16732H9.33337V4.66732H18.6667V8.16732ZM5.83337 11.6673V14.0007H9.33337V11.6673H5.83337ZM18.6667 18.6673V23.334H9.33337V18.6673H18.6667Z"
                fill="#05595B"
              />
            </svg>
          </Box>

          <Box
            sx={{
              marginRight: "12px",
              "&:hover svg path": {
                fill: "#00AA3A",
              },
            }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="25"
              height="25"
              viewBox="0 0 25 25"
              fill="none"
            >
              <path
                d="M19.4175 1.7L17.8862 0H5.8275C4.9575 0 4.62125 0.645 4.62125 1.14875V5.68625H6.3125V2.06625C6.3125 1.87375 6.475 1.71125 6.6625 1.71125H15.2913C15.4812 1.71125 15.5763 1.745 15.5763 1.90125V7.92625H21.7175C21.9587 7.92625 22.0525 8.05125 22.0525 8.23375V22.9463C22.0525 23.2537 21.9275 23.3 21.74 23.3H6.6625C6.56952 23.2977 6.48106 23.2595 6.41576 23.1932C6.35047 23.127 6.31345 23.038 6.3125 22.945V21.6H4.6325V23.7188C4.61 24.4688 5.01 25 5.8275 25H22.575C23.45 25 23.7488 24.3663 23.7488 23.7887V6.48375L23.3113 6.00875L19.4175 1.7ZM17.295 1.9L17.7787 2.4425L21.0238 6.00875L21.2025 6.225H17.8862C17.6362 6.225 17.4775 6.18375 17.4112 6.1C17.345 6.01875 17.3062 5.8875 17.295 5.70875V1.9ZM15.9325 13.3337H21.6537V15.0013H15.9312L15.9325 13.3337ZM15.9325 10.0013H21.6537V11.6675H15.9312L15.9325 10.0013ZM15.9325 16.6675H21.6537V18.335H15.9312L15.9325 16.6675ZM1.25 7.0325V20.3662H14.3313V7.0325H1.25ZM7.79125 14.7875L6.99125 16.01H7.79125V17.5H3.77L6.6875 13.1125L4.1025 9.1675H6.2625L7.7925 11.4625L9.32125 9.1675H11.48L8.89 13.1125L11.8113 17.5H9.57L7.79125 14.7875Z"
                fill="#05595B"
              />
            </svg>
          </Box>

          <Box
            sx={{
              marginRight: "32px",
              "&:hover svg path": {
                fill: "#00AA3A",
              },
            }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="25"
              height="25"
              viewBox="0 0 25 25"
              fill="none"
            >
              <g clipPath="url(#clip0_993_402828)">
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M17.2143 1.78571C17.2143 1.44472 17.3497 1.1177 17.5909 0.876577C17.832 0.635459 18.159 0.5 18.5 0.5L21.5 0.5C23.156 0.5 24.5 1.844 24.5 3.5V6.5C24.5 6.84099 24.3645 7.16802 24.1234 7.40914C23.8823 7.65026 23.5553 7.78571 23.2143 7.78571C22.8733 7.78571 22.5463 7.65026 22.3051 7.40914C22.064 7.16802 21.9286 6.84099 21.9286 6.5V3.5C21.9286 3.38634 21.8834 3.27733 21.803 3.19695C21.7227 3.11658 21.6137 3.07143 21.5 3.07143H18.5C18.159 3.07143 17.832 2.93597 17.5909 2.69485C17.3497 2.45373 17.2143 2.12671 17.2143 1.78571ZM0.5 12.5C0.5 12.159 0.635459 11.832 0.876577 11.5909C1.1177 11.3497 1.44472 11.2143 1.78571 11.2143H23.2143C23.5553 11.2143 23.8823 11.3497 24.1234 11.5909C24.3645 11.832 24.5 12.159 24.5 12.5C24.5 12.841 24.3645 13.168 24.1234 13.4091C23.8823 13.6503 23.5553 13.7857 23.2143 13.7857H1.78571C1.44472 13.7857 1.1177 13.6503 0.876577 13.4091C0.635459 13.168 0.5 12.841 0.5 12.5ZM3.07143 3.5C3.07143 3.38634 3.11658 3.27733 3.19695 3.19695C3.27733 3.11658 3.38634 3.07143 3.5 3.07143H6.5C6.84099 3.07143 7.16802 2.93597 7.40914 2.69485C7.65026 2.45373 7.78571 2.12671 7.78571 1.78571C7.78571 1.44472 7.65026 1.1177 7.40914 0.876577C7.16802 0.635459 6.84099 0.5 6.5 0.5L3.5 0.5C2.70435 0.5 1.94129 0.81607 1.37868 1.37868C0.81607 1.94129 0.5 2.70435 0.5 3.5L0.5 6.5C0.5 6.84099 0.635459 7.16802 0.876577 7.40914C1.1177 7.65026 1.44472 7.78571 1.78571 7.78571C2.12671 7.78571 2.45373 7.65026 2.69485 7.40914C2.93597 7.16802 3.07143 6.84099 3.07143 6.5V3.5ZM23.2143 17.2143C23.5553 17.2143 23.8823 17.3497 24.1234 17.5909C24.3645 17.832 24.5 18.159 24.5 18.5V21.5C24.5 22.2957 24.1839 23.0587 23.6213 23.6213C23.0587 24.1839 22.2957 24.5 21.5 24.5H18.5C18.159 24.5 17.832 24.3645 17.5909 24.1234C17.3497 23.8823 17.2143 23.5553 17.2143 23.2143C17.2143 22.8733 17.3497 22.5463 17.5909 22.3051C17.832 22.064 18.159 21.9286 18.5 21.9286H21.5C21.6137 21.9286 21.7227 21.8834 21.803 21.803C21.8834 21.7227 21.9286 21.6137 21.9286 21.5V18.5C21.9286 18.159 22.064 17.832 22.3051 17.5909C22.5463 17.3497 22.8733 17.2143 23.2143 17.2143ZM3.07143 18.5C3.07143 18.159 2.93597 17.832 2.69485 17.5909C2.45373 17.3497 2.12671 17.2143 1.78571 17.2143C1.44472 17.2143 1.1177 17.3497 0.876577 17.5909C0.635459 17.832 0.5 18.159 0.5 18.5L0.5 21.5C0.5 23.156 1.844 24.5 3.5 24.5H6.5C6.84099 24.5 7.16802 24.3645 7.40914 24.1234C7.65026 23.8823 7.78571 23.5553 7.78571 23.2143C7.78571 22.8733 7.65026 22.5463 7.40914 22.3051C7.16802 22.064 6.84099 21.9286 6.5 21.9286H3.5C3.38634 21.9286 3.27733 21.8834 3.19695 21.803C3.11658 21.7227 3.07143 21.6137 3.07143 21.5V18.5Z"
                  fill="#05595B"
                />
              </g>
              <defs>
                <clipPath id="clip0_993_402828">
                  <rect
                    width="24"
                    height="24"
                    fill="white"
                    transform="translate(0.5 0.5)"
                  />
                </clipPath>
              </defs>
            </svg>
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default QuotationsOrderHeader;
