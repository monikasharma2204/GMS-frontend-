import React from "react";
import { Box, Typography, Checkbox, TextField } from "@mui/material";
import {
  keyEditState,
  memoInfoState,
  selectedCurrencyState,
} from "recoil/MemoOutReturn/MemoState.js";
import { useRecoilState } from "recoil";
import CustomTextField from "component/MemoIn/items/CustomTextField";

const CalculationComponent = ({

  
  state,
  calculateTotalAmountAfterDiscount,
  handleDiscountPercentToggle,
  handleDiscountPercentChange,
  handleDiscountAmountToggle,
  calculateSubTotalAfterItemDiscounts,
  handleDiscountAmountChange,
  handleVATToggle,
  handleVATChange,
  handleOtherChargeChange,
  onNoteChange,
  calculateTotalAfterDiscountPercent,
  calculateTotalAfterDiscount,
  calculateTotalAfterVAT,
  calculateGrandTotal,
  formatNumberWithCommas,
  selectedCurrency,
  note,
  disabled = false
}) =>  
  
  {
 const [memoInfo, setMemoInfo] = useRecoilState(memoInfoState);



    return (
        <>
    <Box sx={{ width: "456px", height: "485px" }}>
      <Typography
        sx={{
          color: "var(--HeadPage, #05595B)",
          fontFamily: "Calibri",
          fontSize: "21px",
          fontStyle: "normal",
          fontWeight: 700,
          lineHeight: "normal",
        }}
      >
        Summary Value
      </Typography>
      <Box sx={{ marginTop: "16px", marginLeft: "30px" }}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <Typography
            sx={{
              color: "var(--Main-Text, #343434)",
              fontFamily: "Calibri",
              fontSize: "16px",
              fontStyle: "normal",
              fontWeight: 400,
            }}
          >
            Sub Total
          </Typography>
          <Box sx={{ display: "flex" }}>
            <TextField
              disabled
              value={formatNumberWithCommas(calculateSubTotalAfterItemDiscounts())}
              variant="outlined"
              fullWidth
              InputProps={{
                sx: {
                  display: "flex",
                  justifyContent: "flex-end",
                  alignItems: "center",
                  flexShrink: 0,
                  borderRadius: "4px",
                  background: "#F0F0F0",
                  height: "24px",
                  "& input": {
                    textAlign: "right",
                    color: "var(--Text-Dis-Field, #9A9A9A)",
                    fontFamily: "Calibri",
                    fontSize: "16px",
                    fontStyle: "normal",
                    fontWeight: 400,
                    lineHeight: "normal",
                  },
                  width: "120px",
                },
              }}
            />
            <Typography sx={{ marginLeft: "8px" }}>{selectedCurrency}</Typography>
          </Box>
        </Box>

        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            marginTop: "6px",
            alignItems: "center",
            marginLeft: "24px",
          }}
        >
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginLeft : "25px"
            }}
          >
            <Checkbox
              sx={{
                color: "#E6E6E6",
                "&.Mui-checked": {
                  color: "#1B84FF",
                },
              }}
                disabled={disabled}
              checked={state.useDiscountPercent}
              onChange={handleDiscountPercentToggle}
            />
            <Typography
              sx={{
                color: "var(--Main-Text, #343434)",
                fontFamily: "Calibri",
                fontSize: "16px",
                fontStyle: "normal",
                fontWeight: 400,
              }}
            >
              Discount
            </Typography>
            <Box sx={{ display: "flex" }}>
              <TextField
                value={state.discount_percent}
                onChange={handleDiscountPercentChange}

                disabled={disabled || !state.useDiscountPercent}
                type="number"
                variant="outlined"
                fullWidth
                InputProps={{
                  sx: {
                    marginLeft: "8px",
                    borderRadius: "4px",
                    background: "#FFF",
                    height: "24px",
                    "& input": {
                      textAlign: "center",
                      color: "var(--Main-Text, #343434)",
                      fontFamily: "Calibri",
                      fontSize: "16px",
                      fontStyle: "normal",
                      fontWeight: 400,
                      lineHeight: "normal",
                    },
                    width: "85px",
                  },
                }}
                inputProps={{
                  inputMode: "numeric",
                  pattern: "[0-9]*",
                  min: 0,
                  max: 100,
                  sx:{
                     '&::-webkit-outer-spin-button': {
                            WebkitAppearance: 'none',
                            margin: 0,
                          },
                          '&::-webkit-inner-spin-button': {
                            WebkitAppearance: 'none',
                            margin: 0,
                          },
                          '&[type=number]': {
                            MozAppearance: 'textfield', // Firefox
                          },
                  }
                }}
              />
            </Box>
            <Typography
              sx={{
                color: "var(--Main-Text, #343434)",
                fontFamily: "Calibri",
                fontSize: "16px",
                fontStyle: "normal",
                fontWeight: 400,
                marginLeft: "8px",
              }}
            >
              %
            </Typography>
          </Box>
          <Box sx={{ display: "flex" }}>
            <TextField
              value={formatNumberWithCommas(Number(calculateTotalAfterDiscountPercent()).toFixed(2))}
              variant="outlined"
              fullWidth
              disabled
            
              InputProps={{
                sx: {
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  flexShrink: 0,
                  borderRadius: "4px",
                  background: "var(--Fill-Dis-Field, #F0F0F0)",
                  height: "24px",
                  "& input": {
                    textAlign: "right",
                    color: "var(--Text-Dis-Field, #9A9A9A)",
                    fontFamily: "Calibri",
                    fontSize: "16px",
                    fontStyle: "normal",
                    fontWeight: 400,
                    lineHeight: "normal",
                  },
                  width: "120px",
                },
              }}
            />
            <Typography sx={{ marginLeft: "8px" }}>{selectedCurrency}</Typography>
          </Box>
        </Box>

        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            marginLeft: "24px",
            alignItems: "center",
            marginTop: "-6px",
            
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center" , marginLeft : "25px" }}>
            <Checkbox
              sx={{
                color: "#E6E6E6",
                "&.Mui-checked": {
                  color: "#1B84FF",
                },
              }}
               disabled={disabled}
              checked={state.useDiscountAmount}
              onChange={handleDiscountAmountToggle}
            />
            <Typography
              sx={{
                color: "var(--Main-Text, #343434)",
                fontFamily: "Calibri",
                fontSize: "16px",
                fontStyle: "normal",
                fontWeight: 400,
              }}
            >
              Discount Amount
            </Typography>
          </Box>
          <Box sx={{ display: "flex" }}>
           <CustomTextField
                                   value={state.discount_amount || ""}
                                   onChange={(value) => handleDiscountAmountChange({ target: { value } })}
                                   disabled={disabled || !state.useDiscountAmount}
                                   type="number"
                                   decimal={2}
                                   formatWithCommas={true}
                                   formatNumberWithCommas={formatNumberWithCommas}
                                     fullWidth
                                   sx={{
                                     "& .MuiOutlinedInput-root": {
                      display: "flex",
                                       justifyContent: "flex-end",
                                       alignItems: "center",
                                       flexShrink: 0,
                                       borderRadius: "4px",
                                       background: "#FFF",
                                       height: "24px",
                                       background: "#FFF",
                                     
                                     "& input": {
                                       textAlign: "right",
                                       color: "var(--Main-Text, #343434)",
                                       fontFamily: "Calibri",
                                       fontSize: "16px",
                                       fontStyle: "normal",
                                       fontWeight: 400,
                                       lineHeight: "normal",
                                                     }         ,    width: "120px",       },
                                   }}
            />
            <Typography sx={{ marginLeft: "8px" }}>{selectedCurrency}</Typography>
          </Box>
        </Box>

        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            marginTop: "6px",
          }}
        >
          <Typography
            sx={{
              color: "var(--Main-Text, #343434)",
              fontFamily: "Calibri",
              fontSize: "16px",
              fontStyle: "normal",
              fontWeight: 400,
            }}
          >
            Total after Discount
          </Typography>
          <Box sx={{ display: "flex" }}>
            <TextField
              disabled
              value={formatNumberWithCommas(calculateTotalAfterDiscount())}
              variant="outlined"
              fullWidth
              InputProps={{
                sx: {
                  display: "flex",
                  justifyContent: "flex-end",
                  alignItems: "center",
                  flexShrink: 0,
                  borderRadius: "4px",
                  background: "var(--Fill-Dis-Field, #F0F0F0)",
                  height: "24px",
                  "& input": {
                    textAlign: "right",
                    color: "var(--Text-Dis-Field, #9A9A9A)",
                    fontFamily: "Calibri",
                    fontSize: "16px",
                    fontStyle: "normal",
                    fontWeight: 400,
                    lineHeight: "normal",
                  },
                  width: "120px",
                },
              }}
            />
            <Typography sx={{ marginLeft: "8px" }}>{selectedCurrency}</Typography>
          </Box>
        </Box>

        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            marginLeft: "24px",
            marginTop: "6px",
            alignItems: "center",
          }}
        >
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginLeft: "25px",
            }}
          >
            <Checkbox
              sx={{
                color: "#E6E6E6",
                "&.Mui-checked": {
                  color: "#1B84FF",
                },
              }}
               disabled={disabled}
              checked={state.useVAT}
              onChange={handleVATToggle}
            />
            <Typography
              sx={{
                color: "var(--Main-Text, #343434)",
                fontFamily: "Calibri",
                fontSize: "16px",
                fontStyle: "normal",
                fontWeight: 400,
              }}
            >
              VAT
            </Typography>
            <Box sx={{ display: "flex" }}>
              <TextField
                value={state.vatAmount}
                onChange={handleVATChange}
                type="number"
                 disabled={disabled || !state.useVAT }
                variant="outlined"
                fullWidth
                InputProps={{
                  sx: {
                    display: "flex",
                    justifyContent: "flex-end",
                    alignItems: "center",
                    marginLeft: "10px",
                    flexShrink: 0,
                    borderRadius: "4px",
                    background: "#FFF",
                    height: "24px",
                    "& input": {
                      textAlign: "center",
                      color: "var(--Main-Text, #343434)",
                      fontFamily: "Calibri",
                      fontSize: "16px",
                      fontStyle: "normal",
                      fontWeight: 400,
                      lineHeight: "normal",
                    },
                    width: "100px",
                  },
                }}
                inputProps={{
                  inputMode: "decimal",
                  pattern: "[0-9]*[.,]?[0-9]*",
                  min: 0,
                  max: 100,
                  step: "any", // allows any decimal value
                  sx:{
                    '&::-webkit-outer-spin-button': {
                           WebkitAppearance: 'none',
                           margin: 0,
                         },
                         '&::-webkit-inner-spin-button': {
                           WebkitAppearance: 'none',
                           margin: 0,
                         },
                         '&[type=number]': {
                           MozAppearance: 'textfield', // Firefox
                         },
                 }
                }}
              />
              <Typography
                sx={{
                  color: "var(--Main-Text, #343434)",
                  fontFamily: "Calibri",
                  fontSize: "16px",
                  fontStyle: "normal",
                  fontWeight: 400,
                  marginLeft: "8px",
                }}
              >
                %
              </Typography>
            </Box>
          </Box>
          <Box sx={{ display: "flex" }}>
            <TextField
             value={formatNumberWithCommas(Number(calculateTotalAfterVAT()).toFixed(2))}
              variant="outlined"
              fullWidth
              disabled
              InputProps={{
                sx: {
                  display: "flex",
                  justifyContent: "flex-end",
                  alignItems: "center",
                  flexShrink: 0,
                  borderRadius: "4px",
                  background: "var(--Fill-Dis-Field, #F0F0F0)",
                  height: "24px",
                  "& input": {
                    textAlign: "right",
                    color: "var(--Text-Dis-Field, #9A9A9A)",
                    fontFamily: "Calibri",
                    fontSize: "16px",
                    fontStyle: "normal",
                    fontWeight: 400,
                    lineHeight: "normal",
                  },
                  width: "120px",
                },
              }}
            />
            <Typography sx={{ marginLeft: "8px" }}>{selectedCurrency}</Typography>
          </Box>
        </Box>

        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            marginTop: "6px",
          }}
        >
          <Typography
            sx={{
              color: "var(--Main-Text, #343434)",
              fontFamily: "Calibri",
              fontSize: "16px",
              fontStyle: "normal",
              fontWeight: 400,
            }}
          >
            Other Charge
          </Typography>
          <Box sx={{ display: "flex" }}>
              <CustomTextField
                                       value={state.otherCharge || ""}
                                       onChange={(value) => handleOtherChargeChange({ target: { value } })}
                                       disabled={disabled}
                                       type="number"
                                       decimal={2}
                                       formatWithCommas={true}
                                       formatNumberWithCommas={formatNumberWithCommas}
                                      fullWidth
                                       sx={{
                                         "& .MuiOutlinedInput-root": {
                         display: "flex",
                                           justifyContent: "flex-end",
                                           alignItems: "center",
                                           flexShrink: 0,
                                           borderRadius: "4px",                  height: "24px",
                                           background: "#FFF",
                                         
                                         "& input": {
                                           textAlign: "right",
                                           color: "var(--Main-Text, #343434)",
                                           fontFamily: "Calibri",
                                           fontSize: "16px",
                                           fontStyle: "normal",
                                           fontWeight: 400,
                                           lineHeight: "normal",
                                         },
                                           width: "120px",
                                         },
                                       }}
            />
            <Typography sx={{ marginLeft: "8px" }}>{selectedCurrency}</Typography>
          </Box>
        </Box>

        <Box
          sx={{
            display: "flex",
            height: "90px",
            justifyContent: "space-between",
            marginTop: "16px",
            alignItems: "center",
            padding: "0px 16px",
            bgcolor: "#F3F3F3",
            border: "1px solid #E6E6E6",
            borderRadius: "4px",
          }}
        >
          <Typography
            sx={{
              color: "var(--Main-Text, #343434)",
              fontFamily: "Calibri",
              fontSize: "24px",
              fontStyle: "normal",
              fontWeight: 700,
              lineHeight: "normal",
            }}
          >
            Grand Total
          </Typography>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Box
                         sx={{
                           width: "200px",
                           fontSize: "32px",
                           fontWeight: 700,
                           fontFamily: "Calibri",
                           color: "var(--Main-Text, #343434)",
                           textAlign: "right",
                           whiteSpace: "normal",
                           wordBreak: "break-word",
                            marginRight:"12px"
                         }}
                       >
                         {formatNumberWithCommas(calculateGrandTotal())}
                       </Box>
                     
            <Typography
              sx={{
                color: "var(--Main-Text, #343434)",
                fontSize: "32px",
                fontFamily: "Calibri",
                fontStyle: "normal",
                fontWeight: 700,
              }}
            >
              {selectedCurrency}
            </Typography>
          </Box>
        </Box>

        <TextField
          value={note}
          label="Note"
          placeholder="This note will be shown on document"
          onChange={(e) => onNoteChange(e.target.value)}
          variant="outlined"
           disabled={disabled}
          InputLabelProps={{
            shrink: true,
          }}
          multiline
          rows={3}
          sx={{
            width: "410px",
            "& .MuiOutlinedInput-root": { borderRadius: "8px" },
            marginTop: "12px",
          }}
        />
      </Box>
    </Box>
  </>

    )
  }
  


export default CalculationComponent;
