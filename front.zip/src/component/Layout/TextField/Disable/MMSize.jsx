import { Box, TextField, Typography } from "@mui/material";

const MMSize = ({ selectedData, isEditing, onCodeChange }) => {
  const handleCodeChange = (event) => {
    onCodeChange(event.target.value);
  };

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        justifyContent: "flex-start",
      }}
    >
      <Box sx={{ display: "flex", marginRight: "52px" }}>
        <Typography
          sx={{
            color: "#343434",
            fontFamily: "Calibri",
            fontSize: "18px",
            fontStyle: "normal",
            fontWeight: 400,
          }}
        >
          MM Size :
        </Typography>
        <Typography
          sx={{
            color: "var(--Red, #E00410)",
            fontFamily: "Calibri",
            fontSize: "16px",
            fontStyle: "normal",
            fontWeight: 400,
            marginLeft: "2px",
            marginTop: "2px",
          }}
        >
          *
        </Typography>
      </Box>

      <TextField
        disabled={!isEditing}
        required
        value={selectedData?.code || ""}
        onChange={handleCodeChange}
        id="outlined-required"
        sx={{
          "& .MuiInputLabel-asterisk": {
            color: "red",
          },
          "& .MuiOutlinedInput-root": {
            borderRadius: "8px",
            backgroundColor: isEditing ? "#FFF" : "#F0F0F0",
            width: "328px",
            height: "42px",
            "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
              borderColor: "#8BB4FF",
            },
          },
        }}
      />
    </Box>
  );
};

export default MMSize;
