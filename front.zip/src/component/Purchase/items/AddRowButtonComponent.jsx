import React from "react";
import { Box, Typography } from "@mui/material";

const AddRowButtonComponent = ({ handleAddRow, disabled = false }) => {
  return (
    <Box
      onClick={disabled ? undefined : handleAddRow}
      sx={{ 
        display: "flex", 
        cursor: disabled ? "not-allowed" : "pointer", 
        marginTop: "11px",
        opacity: disabled ? 0.5 : 1
      }}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
      >
        <path
          d="M18 12.9961H13V17.9961C13 18.2613 12.8946 18.5157 12.7071 18.7032C12.5196 18.8907 12.2652 18.9961 12 18.9961C11.7348 18.9961 11.4804 18.8907 11.2929 18.7032C11.1054 18.5157 11 18.2613 11 17.9961V12.9961H6C5.73478 12.9961 5.48043 12.8907 5.29289 12.7032C5.10536 12.5157 5 12.2613 5 11.9961C5 11.7309 5.10536 11.4765 5.29289 11.289C5.48043 11.1015 5.73478 10.9961 6 10.9961H11V5.99609C11 5.73088 11.1054 5.47652 11.2929 5.28899C11.4804 5.10145 11.7348 4.99609 12 4.99609C12.2652 4.99609 12.5196 5.10145 12.7071 5.28899C12.8946 5.47652 13 5.73088 13 5.99609V10.9961H18C18.2652 10.9961 18.5196 11.1015 18.7071 11.289C18.8946 11.4765 19 11.7309 19 11.9961C19 12.2613 18.8946 12.5157 18.7071 12.7032C18.5196 12.8907 18.2652 12.9961 18 12.9961Z"
          fill="#1B84FF"
        />
      </svg>
      <Typography
        sx={{
          color: "#1B84FF",
          fontFamily: "Calibri",
          fontSize: "18px",
          fontStyle: "normal",
          fontWeight: 700,
          lineHeight: "noemal",
        }}
      >
        Add Row
      </Typography>
    </Box>
  );
};

export default AddRowButtonComponent;