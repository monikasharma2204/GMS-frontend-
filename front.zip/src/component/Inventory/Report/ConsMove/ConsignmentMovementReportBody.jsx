import React, { useState, useEffect } from "react";
import dayjs from "dayjs";
import {
  Box,
  Typography,
  TextField,
  InputAdornment,
  FormControl,
  Select,
  MenuItem,
  CircularProgress,
} from "@mui/material";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { getConsignmentMovements } from "../../../../services/consignmentMovementService.js";
import ConsignmentMovementReportInSide from "./ConsignmentMovementReportInSide.jsx";
import { exportConsignmentToExcel } from "../../../../helpers/consignmentExcelHelper.js";
import FooterReport from "../../../Layout/FooterReport.jsx";

const ConsignmentMovementReportBody = ({ exportTrigger }) => {
  const [rowPP, setRowPP] = React.useState("");
  const [stockMovements, setStockMovements] = useState([]);
  const [filteredStockMovements, setFilteredStockMovements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [startDate, setStartDate] = useState(dayjs());
  const [endDate, setEndDate] = useState(dayjs());
  const [selectedItem, setSelectedItem] = useState(null);

  const lastExportTrigger = React.useRef(exportTrigger);

  const handleExportExcel = () => {
    try {
      if (!filteredStockMovements || filteredStockMovements.length === 0) {
        alert("No data to export");
        return;
      }

      const itemHeaders = [
        ["#", "Memo No.", "Account", "Lot", "Stone", "Shape", "Size", "Color", "Cutting", "Quality", "Clarity", "In", "In", "Out", "Out", "Balance", "Balance"],
        ["", "", "", "", "", "", "", "", "", "", "", "Cts", "Pcs", "Cts", "Pcs", "Cts", "Pcs"]
      ];

      const itemRows = filteredStockMovements.map((item, index) => [
        index + 1,
        item.invoice_no || "",
        typeof item.account === "object" ? (item.account?.vendor_code_name || item.account?.label || "") : (item.account || "---"),
        item.lot_no || "",
        item.stone || "",
        item.shape || "",
        item.size || "",
        item.color || "",
        item.cutting || "",
        item.quality || "",
        item.clarity || "",
        Number(item.in_weight || 0),
        Number(item.in_pcs || 0),
        Number(item.out_weight || 0),
        Number(item.out_pcs || 0),
        Number(item.balance_weight || 0),
        Number(item.balance_pcs || 0)
      ]);

      const merges = [
        { s: { r: 2, c: 0 }, e: { r: 3, c: 0 } }, // #
        { s: { r: 2, c: 1 }, e: { r: 3, c: 1 } }, // Memo No.
        { s: { r: 2, c: 2 }, e: { r: 3, c: 2 } }, // Account
        { s: { r: 2, c: 3 }, e: { r: 3, c: 3 } }, // Lot
        { s: { r: 2, c: 4 }, e: { r: 3, c: 4 } }, // Stone
        { s: { r: 2, c: 5 }, e: { r: 3, c: 5 } }, // Shape
        { s: { r: 2, c: 6 }, e: { r: 3, c: 6 } }, // Size
        { s: { r: 2, c: 7 }, e: { r: 3, c: 7 } }, // Color
        { s: { r: 2, c: 8 }, e: { r: 3, c: 8 } }, // Cutting
        { s: { r: 2, c: 9 }, e: { r: 3, c: 9 } }, // Quality
        { s: { r: 2, c: 10 }, e: { r: 3, c: 10 } }, // Clarity
        { s: { r: 2, c: 11 }, e: { r: 2, c: 12 } }, // In
        { s: { r: 2, c: 13 }, e: { r: 2, c: 14 } }, // Out
        { s: { r: 2, c: 15 }, e: { r: 2, c: 16 } }  // Balance
      ];

      exportConsignmentToExcel({
        filename: "Consignment Movement Report List",
        sheetName: "Consignment Movement Report",
        summaryHeaders: ["Total Items"],
        summaryValues: [stockMovements.length],
        itemHeaders,
        itemRows,
        merges
      });

    } catch (err) {
      console.error(err);
      alert("Failed to export Excel");
    }
  };

  useEffect(() => {
    if (exportTrigger > lastExportTrigger.current) {
      handleExportExcel();
    }
    lastExportTrigger.current = exportTrigger;
  }, [exportTrigger]);

  const fetchStockMovements = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await getConsignmentMovements();
      const movements = Array.isArray(result) ? result : (result?.data || []);
      setStockMovements(movements);
    } catch (err) {
      setError(err.message || 'Failed to fetch consignment movements');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStockMovements();
  }, []);

  useEffect(() => {
    let filtered = stockMovements;
    if (searchTerm) {
      filtered = filtered.filter(item =>
        item.invoice_no?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.stone_code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.lot_no?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.stone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.shape?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    setFilteredStockMovements(filtered);
  }, [stockMovements, searchTerm]);

  const handleChange = (event) => {
    setRowPP(event.target.value);
  };

  const handleRowClick = (item) => {
    setSelectedItem(item);
  };

  const handleBackClick = () => {
    setSelectedItem(null);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '400px' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '400px' }}>
        <Typography color="error">Error: {error}</Typography>
      </Box>
    );
  }

  if (selectedItem) {
    return (
      <ConsignmentMovementReportInSide
        selectedItem={selectedItem}
        onBack={handleBackClick}
        exportTrigger={exportTrigger}
      />
    );
  }

  const FilterIcon = () => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="15"
      height="14"
      viewBox="0 0 15 14"
      fill="none"
      style={{ marginLeft: "4px" }}
    >
      <path
        d="M2.83333 1.75H12.1667C12.3214 1.75 12.4697 1.81146 12.5791 1.92085C12.6885 2.03025 12.75 2.17862 12.75 2.33333V3.2585C12.75 3.4132 12.6885 3.56155 12.5791 3.67092L8.83758 7.41242C8.72818 7.52179 8.6667 7.67014 8.66667 7.82483V11.5028C8.66666 11.5914 8.64645 11.6789 8.60755 11.7586C8.56866 11.8383 8.51211 11.9081 8.44221 11.9626C8.3723 12.0172 8.29088 12.0551 8.20414 12.0734C8.11739 12.0918 8.0276 12.0901 7.94158 12.0686L6.77492 11.7769C6.64877 11.7453 6.53681 11.6725 6.4568 11.57C6.37679 11.4674 6.33334 11.3411 6.33333 11.2111V7.82483C6.3333 7.67014 6.27182 7.52179 6.16242 7.41242L2.42092 3.67092C2.31151 3.56155 2.25003 3.4132 2.25 3.2585V2.33333C2.25 2.17862 2.31146 2.03025 2.42085 1.92085C2.53025 1.81146 2.67862 1.75 2.83333 1.75Z"
        stroke="#666666"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );

  return (
    <>
      <Box sx={{ marginTop: "12px" }}>
        <Box sx={{ padding: "2px 32px 0px 32px", minHeight: "687px", backgroundColor: "#F8F8F8" }}>
          {/* Header Controls */}
          <Box sx={{ padding: "24px 32px", borderRadius: "5px 5px 0px 0px" }}>
            <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <Box sx={{ display: "flex", alignItems: "center", backgroundColor: "#FAFAFA", }}>
                <Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "20px", fontWeight: 700 }}>Consignment Movement Report List</Typography>

              </Box>
              <Box sx={{ display: "flex", alignItems: "center", backgroundColor: "#FAFAFA", }}>
                <Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 400 }}>Date :</Typography>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DatePicker value={startDate} onChange={(newValue) => setStartDate(newValue)} format="DD/MM/YYYY" sx={{ "& .MuiOutlinedInput-root": { borderRadius: "8px", backgroundColor: "#FFF", width: "150px", height: "34px", "& .MuiInputBase-input": { fontSize: "16px", fontFamily: "Calibri" } }, marginRight: "8px", marginLeft: "8px" }} />
                </LocalizationProvider>
                <Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 400 }}>To</Typography>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DatePicker value={endDate} onChange={(newValue) => setEndDate(newValue)} format="DD/MM/YYYY" sx={{ "& .MuiOutlinedInput-root": { borderRadius: "8px", backgroundColor: "#FFF", width: "150px", height: "34px", "& .MuiInputBase-input": { fontSize: "16px", fontFamily: "Calibri" } }, marginRight: "24px", marginLeft: "8px" }} />
                </LocalizationProvider>
                <TextField placeholder="Search List ..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} InputProps={{ startAdornment: (<InputAdornment position="start"> <svg width="20" height="20" viewBox="0 0 24 24" fill="none"> <path fillRule="evenodd" clipRule="evenodd" d="M10.4993 2C9.14387 2.00012 7.80814 2.32436 6.60353 2.94569C5.39893 3.56702 4.36037 4.46742 3.57451 5.57175C2.78866 6.67609 2.27829 7.95235 2.08599 9.29404C1.89368 10.6357 2.02503 12.004 2.46906 13.2846C2.91308 14.5652 3.65692 15.7211 4.63851 16.6557C5.6201 17.5904 6.81098 18.2768 8.11179 18.6576C9.4126 19.0384 10.7856 19.1026 12.1163 18.8449C13.447 18.5872 14.6967 18.015 15.7613 17.176L19.4133 20.828C19.6019 21.0102 19.8545 21.111 20.1167 21.1087C20.3789 21.1064 20.6297 21.0012 20.8151 20.8158C21.0005 20.6304 21.1057 20.3796 21.108 20.1174C21.1102 19.8552 21.0094 19.6026 20.8273 19.414L17.1753 15.762C18.1633 14.5086 18.7784 13.0024 18.9504 11.4157C19.1223 9.82905 18.8441 8.22602 18.1475 6.79009C17.4509 5.35417 16.3642 4.14336 15.0116 3.29623C13.659 2.44911 12.0952 1.99989 10.4993 2ZM3.99928 10.5C3.99928 8.77609 4.6841 7.12279 5.90308 5.90381C7.12207 4.68482 8.77537 4 10.4993 4C12.2232 4 13.8765 4.68482 15.0955 5.90381C16.3145 7.12279 16.9993 8.77609 16.9993 10.5C16.9993 12.2239 16.3145 13.8772 15.0955 15.0962C13.8765 16.3152 12.2232 17 10.4993 17C8.77537 17 7.12207 16.3152 5.90308 15.0962C4.6841 13.8772 3.99928 12.2239 3.99928 10.5Z" fill="#57646F" /> </svg> </InputAdornment>), sx: { color: "#9A9A9A", fontFamily: "Calibri", fontSize: "16px" }, }} sx={{ "& .MuiOutlinedInput-root": { borderRadius: "10px", backgroundColor: "#FFF", width: "250px", height: "35px" }, marginRight: "24px" }} />
                <Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 400 }}>Rows per page</Typography>
                <FormControl sx={{ borderRadius: "8px", height: "34px", width: "69px", marginLeft: "8px" }}>
                  <Select sx={{ padding: "0px", borderRadius: "8px", height: "34px", width: "69px", backgroundColor: "#FFF", fontFamily: "Calibri" }} value={rowPP} onChange={handleChange}>
                    <MenuItem value={10}>10</MenuItem>
                    <MenuItem value={20}>20</MenuItem>
                    <MenuItem value={30}>30</MenuItem>
                  </Select>
                </FormControl>
              </Box>
            </Box>

          </Box>

          {/* Table Container */}
          <Box sx={{ maxWidth: "1587px", borderRadius: "5px", border: "1px solid #C6C6C8", overflow: "hidden", backgroundColor: "#FAFAFA", }}>
            <Box sx={{ display: "flex", height: "580px", overflow: "auto", "&::-webkit-scrollbar": { height: "10px", width: "5px" }, "&::-webkit-scrollbar-track": { background: "#FAFAFA" }, "&::-webkit-scrollbar-thumb": { background: "#919191", borderRadius: "5px" }, bgcolor: "#FFF" }}>
              <Box sx={{ minWidth: "1844px" }}>
                {/* Fixed Header Row */}
                <Box sx={{ height: "64px", bgcolor: "#F2F2F2", borderBottom: "1px solid #EDEDED", display: "flex", alignItems: "center", textAlign: "center", width: "1972px" }}>
                  <Box sx={{ width: "50px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", justifyContent: "center", alignItems: "center", boxSizing: "border-box" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>#</Typography></Box>
                  <Box sx={{ width: "120px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", justifyContent: "left", alignItems: "center", boxSizing: "border-box", padding: "0 8px" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>Memo No.</Typography><FilterIcon /></Box>
                  <Box sx={{ width: "130px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", justifyContent: "left", alignItems: "center", boxSizing: "border-box", padding: "0 8px" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>Account</Typography><FilterIcon /></Box>
                  <Box sx={{ width: "80px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", justifyContent: "left", alignItems: "center", boxSizing: "border-box", padding: "0 8px" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>Lot</Typography></Box>
                  <Box sx={{ width: "120px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", justifyContent: "left", alignItems: "center", boxSizing: "border-box", padding: "0 8px" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>Stone</Typography><FilterIcon /></Box>
                  <Box sx={{ width: "120px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", justifyContent: "left", alignItems: "center", boxSizing: "border-box", padding: "0 8px" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>Shape</Typography><FilterIcon /></Box>
                  <Box sx={{ width: "120px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", justifyContent: "left", alignItems: "center", boxSizing: "border-box", padding: "0 8px" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>Size</Typography><FilterIcon /></Box>
                  <Box sx={{ width: "120px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", justifyContent: "left", alignItems: "center", boxSizing: "border-box", padding: "0 8px" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>Color</Typography><FilterIcon /></Box>
                  <Box sx={{ width: "120px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", justifyContent: "left", alignItems: "center", boxSizing: "border-box", padding: "0 8px" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>Cutting</Typography><FilterIcon /></Box>
                  <Box sx={{ width: "120px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", justifyContent: "left", alignItems: "center", boxSizing: "border-box", padding: "0 8px" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>Quality</Typography><FilterIcon /></Box>
                  <Box sx={{ width: "120px", borderRight: "1px solid #C6C6C8", height: "100%", display: "flex", justifyContent: "left", alignItems: "center", boxSizing: "border-box", padding: "0 8px" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>Clarity</Typography><FilterIcon /></Box>

                  {/* In Section */}
                  <Box sx={{ height: "100%", width: "251px", boxSizing: "border-box" }}>
                    <Box sx={{ height: "50%", bgcolor: "rgba(5, 89, 91, 0.40)", borderRight: "1px solid #EDEDED", display: "flex", justifyContent: "center", alignItems: "center", width: "251px", boxSizing: "border-box" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>In</Typography></Box>
                    <Box sx={{ height: "50%", display: "flex", width: "251px", boxSizing: "border-box" }}>
                      <Box sx={{ padding: "0 8px", width: "126px", display: "flex", justifyContent: "right", alignItems: "center", borderRight: "1px solid #EDEDED", bgcolor: "rgba(5, 89, 91, 0.20)", height: "100%", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "14px", fontWeight: 700 }}>Pcs</Typography></Box>
                      <Box sx={{ padding: "0 8px", width: "125px", display: "flex", justifyContent: "right", alignItems: "center", borderRight: "1px solid #EDEDED", bgcolor: "rgba(5, 89, 91, 0.20)", height: "100%", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "14px", fontWeight: 700 }}>Cts</Typography></Box>

                    </Box>
                  </Box>

                  {/* Out Section */}
                  <Box sx={{ height: "100%", width: "251px", boxSizing: "border-box" }}>
                    <Box sx={{ height: "50%", bgcolor: "rgba(224, 4, 16, 0.40)", borderRight: "1px solid #EDEDED", display: "flex", justifyContent: "center", alignItems: "center", width: "251px", boxSizing: "border-box" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>Out</Typography></Box>
                    <Box sx={{ height: "50%", display: "flex", width: "251px", boxSizing: "border-box" }}>
                      <Box sx={{ padding: "0 8px", width: "126px", display: "flex", justifyContent: "right", alignItems: "center", borderRight: "1px solid #EDEDED", bgcolor: "rgba(224, 4, 16, 0.20)", height: "100%", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "14px", fontWeight: 700 }}>Pcs</Typography></Box>
                      <Box sx={{ padding: "0 8px", width: "125px", display: "flex", justifyContent: "right", alignItems: "center", borderRight: "1px solid #EDEDED", bgcolor: "rgba(224, 4, 16, 0.20)", height: "100%", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "14px", fontWeight: 700 }}>Cts</Typography></Box>

                    </Box>
                  </Box>

                  {/* Balance Section */}
                  <Box sx={{ height: "100%", width: "251px", boxSizing: "border-box" }}>
                    <Box sx={{ height: "50%", bgcolor: "rgba(139, 180, 255, 0.40)", borderRight: "1px solid #EDEDED", display: "flex", justifyContent: "center", alignItems: "center", width: "251px", boxSizing: "border-box" }}><Typography sx={{ color: "#343434", fontFamily: "Calibri", fontSize: "16px", fontWeight: 700 }}>Balance</Typography></Box>
                    <Box sx={{ height: "50%", display: "flex", width: "251px", boxSizing: "border-box" }}>
                      <Box sx={{ padding: "0 8px", width: "126px", display: "flex", justifyContent: "right", alignItems: "center", bgcolor: "rgba(139, 180, 255, 0.20)", borderRight: "1px solid #EDEDED", height: "100%", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "14px", fontWeight: 700 }}>Pcs</Typography></Box>
                      <Box sx={{ padding: "0 8px", width: "125px", display: "flex", justifyContent: "right", alignItems: "center", borderRight: "1px solid #EDEDED", bgcolor: "rgba(139, 180, 255, 0.20)", height: "100%", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "14px", fontWeight: 700 }}>Cts</Typography></Box>

                    </Box>
                  </Box>
                </Box>

                {/* Table Content Rows */}
                <Box sx={{ width: "1844px" }}>
                  {filteredStockMovements.map((item, index) => (
                    <Box key={index} onClick={() => handleRowClick(item)} sx={{ height: "42px", display: "flex", alignItems: "center", borderBottom: "1px solid #EDEDED", cursor: "pointer", "&:hover": { bgcolor: "#F5F8FF" }, width: "1972px" }}>
                      <Box sx={{ width: "50px", textAlign: "center", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{index + 1}</Typography></Box>
                      <Box sx={{ width: "120px", padding: "0 8px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", alignItems: "center", justifyContent: "left", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{item.invoice_no || "---"}</Typography></Box>
                      <Box sx={{ width: "130px", padding: "0 8px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", alignItems: "center", justifyContent: "left", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{typeof item.account === "object" ? (item.account?.vendor_code_name || item.account?.label || "") : (item.account || "---")}</Typography></Box>
                      <Box sx={{ width: "80px", padding: "0 8px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", alignItems: "center", justifyContent: "left", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{item.lot_no || "---"}</Typography></Box>
                      <Box sx={{ width: "120px", padding: "0 8px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", alignItems: "center", justifyContent: "left", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{item.stone || "---"}</Typography></Box>
                      <Box sx={{ width: "120px", padding: "0 8px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", alignItems: "center", justifyContent: "left", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{item.shape || "---"}</Typography></Box>
                      <Box sx={{ width: "120px", padding: "0 8px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", alignItems: "center", justifyContent: "left", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{item.size || "---"}</Typography></Box>
                      <Box sx={{ width: "120px", padding: "0 8px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", alignItems: "center", justifyContent: "left", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{item.color || "---"}</Typography></Box>
                      <Box sx={{ width: "120px", padding: "0 8px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", alignItems: "center", justifyContent: "left", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{item.cutting || "---"}</Typography></Box>
                      <Box sx={{ width: "120px", padding: "0 8px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", alignItems: "center", justifyContent: "left", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{item.quality || "---"}</Typography></Box>
                      <Box sx={{ width: "120px", padding: "0 8px", borderRight: "1px solid #EDEDED", height: "100%", display: "flex", alignItems: "center", justifyContent: "left", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{item.clarity || "---"}</Typography></Box>

                      {/* In Data */}
                      <Box sx={{ width: "126px", padding: "0 8px", borderRight: "1px solid #EDEDED", textAlign: "right", height: "100%", display: "flex", alignItems: "center", justifyContent: "flex-end", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{Number(item.in_pcs || 0)}</Typography></Box>
                      <Box sx={{ width: "125px", padding: "0 8px", borderRight: "1px solid #EDEDED", textAlign: "right", height: "100%", display: "flex", alignItems: "center", justifyContent: "flex-end", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{Number(item.in_weight || 0).toFixed(3)}</Typography></Box>


                      {/* Out Data */}
                      <Box sx={{ width: "126px", padding: "0 8px", borderRight: "1px solid #EDEDED", textAlign: "right", height: "100%", display: "flex", alignItems: "center", justifyContent: "flex-end", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{Number(item.out_pcs || 0)}</Typography></Box>
                      <Box sx={{ width: "125px", padding: "0 8px", borderRight: "1px solid #EDEDED", textAlign: "right", height: "100%", display: "flex", alignItems: "center", justifyContent: "flex-end", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{Number(item.out_weight || 0).toFixed(3)}</Typography></Box>


                      {/* Balance Data */}
                      <Box sx={{ width: "126px", padding: "0 8px", textAlign: "right", height: "100%", display: "flex", alignItems: "center", justifyContent: "flex-end", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{Number(item.balance_pcs || 0)}</Typography></Box>
                      <Box sx={{ width: "125px", padding: "0 8px", borderRight: "1px solid #EDEDED", textAlign: "right", height: "100%", display: "flex", alignItems: "center", justifyContent: "flex-end", boxSizing: "border-box" }}><Typography sx={{ fontFamily: "Calibri", fontSize: "16px", fontWeight: 400, color: "#343434" }}>{Number(item.balance_weight || 0).toFixed(3)}</Typography></Box>

                    </Box>
                  ))}
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
        <FooterReport onExcel={handleExportExcel} />
      </Box >
    </>
  );
};

export default ConsignmentMovementReportBody;
